<?php
$sql = new mysqli("localhost", "root", "", "tclk");
?>