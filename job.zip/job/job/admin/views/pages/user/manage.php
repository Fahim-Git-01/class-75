<?php require_once 'models/user.class.php'; ?>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Create User</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active">Users</li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>
    <!-- Content Wrapper. Contains page content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <a href="create-user" class="btn btn-sm btn-dark">Create User</a>
                        </div>

                        <!-- /.card-header -->
                        <div class="card-body p-0">
                            <div class="table-responsive">
                                <table class="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Name</th>
                                            <th>Email</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>11</td>
                                            <td>Keya</td>
                                            <td>k@mail.com</td>
                                            <td>
                                                <div class="btn-group">
                                                    <button type="button" class="btn btn-sm btn-default"><i
                                                            class="fa fa-eye text-primary"></i></button>
                                                    <a href="edit-user?id=11" class="btn btn-sm btn-default"><i
                                                            class="fa fa-edit text-success"></i></a>
                                                    <form method="POST">
                                                        <input type="hidden" name="delete_id" value="11">
                                                        <button type="submit" class="btn btn-sm btn-default"><i
                                                                class="fa fa-trash text-danger"></i></button>
                                                    </form>
                                                </div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>10</td>
                                            <td>Mina</td>
                                            <td>m@mail.com</td>
                                            <td>
                                                <div class="btn-group">
                                                    <button type="button" class="btn btn-sm btn-default"><i
                                                            class="fa fa-eye text-primary"></i></button>
                                                    <a href="edit-user?id=10" class="btn btn-sm btn-default"><i
                                                            class="fa fa-edit text-success"></i></a>
                                                    <form method="POST">
                                                        <input type="hidden" name="delete_id" value="10">
                                                        <button type="submit" class="btn btn-sm btn-default"><i
                                                                class="fa fa-trash text-danger"></i></button>
                                                    </form>
                                                </div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>9</td>
                                            <td>Lali</td>
                                            <td>lali@mail.com</td>
                                            <td>
                                                <div class="btn-group">
                                                    <button type="button" class="btn btn-sm btn-default"><i
                                                            class="fa fa-eye text-primary"></i></button>
                                                    <a href="edit-user?id=9" class="btn btn-sm btn-default"><i
                                                            class="fa fa-edit text-success"></i></a>
                                                    <form method="POST">
                                                        <input type="hidden" name="delete_id" value="9">
                                                        <button type="submit" class="btn btn-sm btn-default"><i
                                                                class="fa fa-trash text-danger"></i></button>
                                                    </form>
                                                </div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>8</td>
                                            <td>Asia</td>
                                            <td>asia@mail.com</td>
                                            <td>
                                                <div class="btn-group">
                                                    <button type="button" class="btn btn-sm btn-default"><i
                                                            class="fa fa-eye text-primary"></i></button>
                                                    <a href="edit-user?id=8" class="btn btn-sm btn-default"><i
                                                            class="fa fa-edit text-success"></i></a>
                                                    <form method="POST">
                                                        <input type="hidden" name="delete_id" value="8">
                                                        <button type="submit" class="btn btn-sm btn-default"><i
                                                                class="fa fa-trash text-danger"></i></button>
                                                    </form>
                                                </div>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>
</div>