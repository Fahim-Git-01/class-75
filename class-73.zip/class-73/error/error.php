<?php
// try{

// }catch(Exception $e){
//     echo $e->getMessage();
// }finally{
//     echo "<br>Finally";
// }

error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', 'error.log');
ini_set('error_log', 'error.log');

echo $user;
get();


?>